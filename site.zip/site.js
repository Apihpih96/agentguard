import { boot } from "./runtime/index.js";
import { scanSite } from "./guard-core.js";
import { renderReport } from "./ui.js";
import { setLastReport } from "./guard-actions.js";

const status = document.querySelector("#assistant-status");
const siteBase = new URL("./", import.meta.url).href;

// Quick scan works even without an LLM key.
document.querySelector("#scan-form").addEventListener("submit", async e => {
  e.preventDefault();
  const url = document.querySelector("#scan-url").value;
  document.querySelector("#report").textContent = "Scanning…";
  const r = await scanSite(url);
  setLastReport(r);
  renderReport(r);
});
document.querySelectorAll(".demos button").forEach(b => b.addEventListener("click", () => {
  document.querySelector("#scan-url").value = new URL(b.dataset.url, location.href).href;
  document.querySelector("#scan-form").requestSubmit();
}));
const pre = new URLSearchParams(location.search).get("url");
if (pre) { document.querySelector("#scan-url").value = pre; document.querySelector("#scan-form").requestSubmit(); }

try {
  await boot("#agent-app", {
    originUrl: siteBase,
    sandboxWorkerUrl: new URL("runtime/sandbox-worker.js", siteBase).href,
  });
  status.textContent = "AgentGuard agents ready. Ask for a deep review of any site.";
} catch (error) {
  status.textContent = `Agents unavailable: ${error.message}. The quick scan still works.`;
  console.error(error);
}
