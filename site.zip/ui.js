const icon = { pass: "✅", warn: "⚠️", fail: "❌" };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export function renderReport(r) {
  const el = document.querySelector("#report");
  if (!el) return;
  const cls = r.score >= 80 ? "good" : r.score >= 50 ? "mid" : "bad";
  el.innerHTML = `
    <div class="score ${cls}"><span>${r.score}</span><small>/100</small></div>
    <p class="verdict">${esc(r.verdict)}${r.network ? ` · ${esc(r.network)}` : ""}</p>
    <h3>Checks</h3>
    <ul>${r.checks.map(c => `<li>${icon[c.status]} <b>${esc(c.group)}</b>: ${esc(c.detail)}</li>`).join("")}</ul>
    <h3>Injection flags</h3>
    ${r.flags.length ? `<ul>${r.flags.map(f => `<li>🚩 <b>${esc(f.agent)}</b>: ${esc(f.label)}${f.match ? ` <code>${esc(f.match)}</code>` : ""}</li>`).join("")}</ul>` : "<p>None found by the quick scan.</p>"}
    <h3>Badge</h3>
    <code class="badge">&lt;a href="${location.origin}${location.pathname}?url=${encodeURIComponent(r.input)}"&gt;AgentGuard ${r.score}/100&lt;/a&gt;</code>`;
}
