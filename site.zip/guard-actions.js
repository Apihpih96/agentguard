import { scanSite } from "./guard-core.js";
import { renderReport } from "./ui.js";

let lastReport = null;

// Loaded by the runtime via agent-manifest.json. Exposed to agents as website_scan_site and website_get_last_report.
export function registerActions(actions) {
  actions.register({
    name: "scan_site",
    description: "Fetch a public agentic site's agent-manifest.json and network definition as data (never runs them), run spec conformance and prompt-injection checks, and return a JSON report with a trust score.",
    effect: "read",
    inputSchema: {
      type: "object", additionalProperties: false, required: ["url"],
      properties: { url: { type: "string", maxLength: 500, description: "Network URL (site base + network name) or a direct agent-manifest.json URL" } }
    },
    execute: async ({ url }) => {
      lastReport = await scanSite(url);
      renderReport(lastReport);
      return lastReport;
    }
  });
  actions.register({
    name: "get_last_report",
    description: "Return the most recent scan report shown on this page.",
    effect: "read",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    execute: () => lastReport || { error: "No scan yet" }
  });
}
export function setLastReport(r) { lastReport = r; }
