// AgentGuard deterministic checks. Pure browser JS, no dependencies.
// Reads public artifacts only, without credentials, and never executes peer code.

const INJECTION_PATTERNS = [
  { id: "override", re: /ignore (all |any )?(previous|prior|above|earlier) (instructions|rules)/i, label: "Tries to override the caller's instructions" },
  { id: "system_prompt", re: /(reveal|print|show|repeat).{0,40}(system prompt|your instructions|hidden prompt)/i, label: "Asks for the caller's system prompt" },
  { id: "secrets", re: /(api[_ -]?key|bearer|access token|password|credential)s?/i, label: "Mentions keys or credentials" },
  { id: "sly_data", re: /sly_data|private context/i, label: "Mentions private context" },
  { id: "exfil", re: /(send|post|forward|upload|fetch).{0,60}https?:\/\//i, label: "Tells the model to send data to a URL" },
  { id: "no_confirm", re: /(without|skip|bypass|no need for).{0,30}(confirm|approval|consent|asking)/i, label: "Tries to skip user confirmation" },
  { id: "exfil_image", re: /!\[[^\]]*\]\(https?:\/\/[^)]*[?&][^)]*[{}=][^)]*\)/i, label: "Markdown image that leaks data through its URL" },
  { id: "roleplay", re: /(you are now|act as|pretend to be).{0,40}(admin|developer|system|unrestricted)/i, label: "Role hijack attempt" }
];
const HIDDEN_CHARS = /[\u200B-\u200F\u202A-\u202E\u2060-\u2064\uFEFF]/;
const SECRET_VALUE = /(sk-[A-Za-z0-9]{16,}|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{30,}|AIza[0-9A-Za-z_-]{30,})/;

const LIMITS = { maxBytes: 1_000_000, timeoutMs: 10_000 };

async function getJson(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), LIMITS.timeoutMs);
  try {
    const res = await fetch(url, { mode: "cors", credentials: "omit", redirect: "follow", signal: ctrl.signal });
    const text = await res.text();
    if (text.length > LIMITS.maxBytes) throw new Error(`File too large (${text.length} bytes)`);
    return { ok: res.ok, status: res.status, finalUrl: res.url, json: res.ok ? JSON.parse(text) : null, raw: text };
  } catch (e) {
    const msg = e.name === "AbortError" ? "Timed out" : e instanceof SyntaxError ? "Not valid JSON" : "Blocked or unreachable (likely CORS or network)";
    return { ok: false, status: 0, error: msg };
  } finally { clearTimeout(t); }
}

// Spec 3.2: a network URL's last path part is the network name; the rest is the site base.
export function parseNetworkUrl(input) {
  const url = new URL(input.trim());
  if (url.pathname.endsWith("agent-manifest.json")) {
    return { base: new URL("./", url).href, network: null };
  }
  const parts = url.pathname.replace(/\/+$/, "").split("/");
  const network = parts.pop() || null;
  return { base: url.origin + parts.join("/") + "/", network };
}

export async function scanSite(input) {
  const checks = [];
  const add = (id, group, status, detail) => checks.push({ id, group, status, detail });
  const report = { input, scannedAt: new Date().toISOString(), checks, flags: [], excerpts: [] };

  let target;
  try { target = parseNetworkUrl(input); } catch { add("url", "Publication", "fail", "Not a valid URL"); return finish(report); }
  const isLocal = /^(localhost|127\.0\.0\.1)$/.test(new URL(target.base).hostname);
  add("https", "Publication", target.base.startsWith("https://") || isLocal ? "pass" : "fail",
      target.base.startsWith("https://") ? "Served over HTTPS" : isLocal ? "Loopback HTTP (dev only)" : "Spec requires HTTPS");

  const manifestUrl = new URL("agent-manifest.json", target.base).href;
  const m = await getJson(manifestUrl);
  report.manifestUrl = manifestUrl;
  if (!m.ok) { add("manifest", "Publication", "fail", `${manifestUrl}: ${m.error || "HTTP " + m.status}`); return finish(report); }
  add("manifest", "Publication", "pass", "agent-manifest.json is public and readable cross-origin (CORS OK)");
  const manifest = m.json;
  if (SECRET_VALUE.test(m.raw)) add("manifest_secrets", "Safety", "fail", "Manifest appears to contain a live API key");

  const nets = Array.isArray(manifest.networks) ? manifest.networks : [];
  add("networks", "Publication", nets.length ? "pass" : "fail", `${nets.length} network(s) listed`);
  for (const n of nets) {
    if (!n.name || !n.front_man || !n.hocon) add(`entry_${n.name || "?"}`, "Publication", "fail", "Network entry missing name, front_man or hocon");
  }
  const entry = target.network ? nets.find(n => n.name === target.network) : nets[0];
  if (target.network && !entry) { add("exact_match", "Publication", "fail", `No network named exactly "${target.network}" (spec says fail, never substitute)`); return finish(report); }
  if (!entry) return finish(report);
  report.network = entry.name;

  const mode = manifest.peer_policy?.mode;
  add("peer_policy", "Safety", mode ? (mode === "open" ? "warn" : "pass") : "warn",
      mode ? `peer_policy mode: ${mode}${mode === "open" ? " (any origin may be contacted)" : ""}` : "No peer_policy declared");
  add("router", "Safety", manifest.llm_router ? "pass" : "warn", manifest.llm_router ? "Declares an LLM router" : "No llm_router metadata");

  const netUrl = new URL(entry.hocon, target.base).href;
  const d = await getJson(netUrl);
  report.networkUrl = netUrl;
  if (!d.ok) { add("network_file", "Publication", "fail", `${netUrl}: ${d.error || "HTTP " + d.status}`); return finish(report); }
  add("network_file", "Publication", "pass", "Network definition fetched");
  if (SECRET_VALUE.test(d.raw)) add("network_secrets", "Safety", "fail", "Network file appears to contain a live API key");
  if (/\$\{[^}]+\}|include\s+"/.test(d.raw)) add("resolved", "Network structure", "fail", "Unresolved HOCON include or substitution");
  else add("resolved", "Network structure", "pass", "Fully resolved, data-only");

  const agents = Array.isArray(d.json.tools) ? d.json.tools : [];
  const names = agents.map(a => a.name);
  const dupes = names.filter((x, i) => names.indexOf(x) !== i);
  add("agents", "Network structure", agents.length >= 2 ? "pass" : "warn", `${agents.length} agent(s)`);
  add("unique_names", "Network structure", dupes.length ? "fail" : "pass", dupes.length ? `Duplicate names: ${[...new Set(dupes)].join(", ")}` : "Agent names are unique");
  add("front_agent", "Network structure", names.includes(entry.front_man) ? "pass" : "fail",
      names.includes(entry.front_man) ? `Front agent "${entry.front_man}" exists` : `Front agent "${entry.front_man}" not found`);

  const missing = [], external = [];
  for (const a of agents) {
    if (!a.function?.description) add(`desc_${a.name}`, "Network structure", "warn", `${a.name} has no function.description`);
    for (const ref of a.tools || []) {
      if (typeof ref === "string") {
        if (/^https?:\/\//.test(ref)) external.push(ref);
        else if (!names.includes(ref) && !ref.startsWith("/")) missing.push(`${a.name} -> ${ref}`);
      } else if (ref && ref.url) external.push(ref.url);
    }
    const raw = `${a.instructions || ""} ${a.function?.description || ""}`;
    if (HIDDEN_CHARS.test(raw)) report.flags.push({ agent: a.name, id: "hidden_chars", label: "Contains invisible characters (text hidden from humans)" });
    // Normalise: strip invisible chars, then also decode any base64 blobs, so hidden payloads are scanned too.
    const visible = raw.replace(new RegExp(HIDDEN_CHARS.source, "g"), "");
    const decoded = [];
    for (const blob of visible.match(/[A-Za-z0-9+/]{40,}={0,2}/g) || []) {
      try {
        const txt = atob(blob);
        if (/^[\x20-\x7E\s]+$/.test(txt)) { decoded.push(txt); report.flags.push({ agent: a.name, id: "base64", label: "Hidden base64 payload", match: txt.slice(0, 80) }); }
      } catch {}
    }
    const seen = new Set();
    for (const text of [visible, ...decoded]) {
      for (const p of INJECTION_PATTERNS) {
        const hit = text.match(p.re);
        if (hit && !seen.has(p.id)) { seen.add(p.id); report.flags.push({ agent: a.name, id: p.id, label: p.label, match: hit[0].slice(0, 80) }); }
      }
    }
    report.excerpts.push({ agent: a.name, instructions: (a.instructions || "").slice(0, 1500) });
  }
  add("references", "Network structure", missing.length ? "fail" : "pass", missing.length ? `Unresolved: ${missing.join("; ")}` : "All local references resolve");
  report.externalRefs = external;
  if (external.length) {
    const allowed = manifest.allowed_peers || [];
    const undeclared = external.filter(u => !allowed.some(p => u.startsWith(p)) && mode !== "open");
    add("peers_declared", "Safety", undeclared.length ? "warn" : "pass",
        undeclared.length ? `External refs not in allowed_peers: ${undeclared.join(", ")}` : "External refs are declared peers");
  }
  report.complete = true;
  return finish(report);
}

function finish(report) {
  const weights = { fail: 12, warn: 4, pass: 0 };
  let score = 100;
  for (const c of report.checks) score -= weights[c.status] || 0;
  // "Mentions" alone are informational; they only cost points alongside a send-to-URL or skip-confirmation flag.
  const strong = report.flags.some(f => f.id === "exfil" || f.id === "exfil_image" || f.id === "no_confirm");
  for (const f of report.flags) {
    if (f.id === "secrets" || f.id === "sly_data") { f.severity = strong ? "high" : "info"; score -= strong ? 8 : 0; }
    else { f.severity = "high"; score -= 10; }
  }
  report.score = Math.max(0, Math.min(100, score));
  if (!report.complete) { report.score = 0; report.verdict = "Could not verify: scan stopped at a failed check"; return report; }
  report.verdict = report.score >= 80 ? "Safe to link" : report.score >= 50 ? "Use with caution" : "Do not link";
  return report;
}
